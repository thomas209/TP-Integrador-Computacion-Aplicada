#!/bin/bash
# ==========================================================
# backup_full.sh - TP integrador Computacion Aplicada
# Genera un backup comprimido (.tar.gz) de un directorio ORIGEN
# en un directorio DESTINO, con la fecha en formato ANSI (YYYYMMDD).
# Ejemplo: /var/log -> log_bkp_20240302.tar.gz
# ==========================================================

ayuda() {
  echo "Uso: $(basename "$0") ORIGEN DESTINO"
  echo "     $(basename "$0") -help"
  echo
  echo "  ORIGEN   directorio a backupear        (ej: /var/log)"
  echo "  DESTINO  directorio donde se guarda    (ej: /backup_dir)"
  echo
  echo "Genera DESTINO/<nombre>_bkp_YYYYMMDD.tar.gz"
  echo "Ejemplo: $(basename "$0") /var/log /backup_dir  ->  /backup_dir/log_bkp_$(date +%Y%m%d).tar.gz"
  echo
  echo "Antes de backupear valida que el origen y el destino esten disponibles"
  echo "(que existan y, si estan en /etc/fstab, que su filesystem este montado)."
}

# --- Opcion de ayuda ---
if [ "$1" = "-help" ] || [ "$1" = "--help" ] || [ "$1" = "-h" ]; then
  ayuda
  exit 0
fi

# --- Validar cantidad de argumentos ---
if [ $# -ne 2 ]; then
  echo "ERROR: se esperan 2 argumentos (origen y destino)." >&2
  ayuda
  exit 1
fi

ORIGEN="${1%/}"
DESTINO="${2%/}"
[ -z "$ORIGEN" ] && ORIGEN="/"
[ -z "$DESTINO" ] && DESTINO="/"

# --- Valida que el filesystem de un directorio este disponible ---
fs_disponible() {
  local dir="$1"
  # Debe existir y ser un directorio
  [ -d "$dir" ] || return 1
  # Si el directorio es un punto de montaje declarado en /etc/fstab, tiene que estar montado
  if awk '$1 !~ /^#/ {print $2}' /etc/fstab | grep -qx "$dir"; then
    mountpoint -q "$dir" || return 2
  fi
  return 0
}

fs_disponible "$ORIGEN"
case $? in
  1) echo "ERROR: el origen '$ORIGEN' no existe o no es un directorio." >&2; exit 2 ;;
  2) echo "ERROR: el filesystem de origen '$ORIGEN' no esta montado." >&2; exit 2 ;;
esac

fs_disponible "$DESTINO"
case $? in
  1) echo "ERROR: el destino '$DESTINO' no existe o no es un directorio." >&2; exit 3 ;;
  2) echo "ERROR: el filesystem de destino '$DESTINO' no esta montado." >&2; exit 3 ;;
esac

if [ ! -w "$DESTINO" ]; then
  echo "ERROR: no hay permiso de escritura en '$DESTINO'." >&2
  exit 3
fi

# --- Nombre del archivo: <nombre>_bkp_YYYYMMDD.tar.gz ---
NOMBRE=$(basename "$ORIGEN")
[ "$NOMBRE" = "/" ] && NOMBRE="raiz"
FECHA=$(date +%Y%m%d)
ARCHIVO="$DESTINO/${NOMBRE}_bkp_${FECHA}.tar.gz"

echo "$(date '+%F %T') Backup de $ORIGEN -> $ARCHIVO"
if tar -czf "$ARCHIVO" -C "$(dirname "$ORIGEN")" "$(basename "$ORIGEN")"; then
  echo "$(date '+%F %T') OK: $(du -h "$ARCHIVO" | cut -f1) $ARCHIVO"
  exit 0
else
  echo "$(date '+%F %T') ERROR: fallo tar al generar $ARCHIVO" >&2
  exit 4
fi
