history
history -w
rm -f /root/.bash_history
journalctl --rotate
journalctl --vacuum-time=1s
apt clean
sync
poweroff
cat /etc/resolv.conf v
powerofff
poweroff
sudo cat /etc/hash 
cd /usr/local/bin/
ls -ltr
ls -l
base64 -d -i < cat /etc/hash 
cat /etc/hash 
cat /etc/hash  > base64 -d -i
cat /etc/hash | base64 -d -i
rm /etc/hash 
chatrr -i /etc/hash 
cd /etc/
ls -l |has
ls -l |hash
ls -ltr 
chatrr +i hash 
chattr -i /etc/hash 
rm /etc/hash 
ls -l
reboot
history
shutdown now
ip -br añip rñls -rootñlsblk
loadkeys us
ip -br a;ip r;ls -la /root;lsblk
tar tzvf Material_Adicional_TPVMCA.tar.gz ;cat /etc/network/interfaces;lsblk -f
dhclient enp0s1;ip -br a;ip r;cat /etc/resolv.conf 
tar xzf Material_Adicional_TPVMCA.tar.gz ;cd Material-;cat indexphp
cat Material_Adicional_TPVMCA/index.php 
head -20 Material_Adicional_TPVMCA/index.php  Material_Adicional_TPVMCA/db.sql 
poweroff
lsblk
dhclient enp0s1;tar xof /dev/sr0 -C /root;bash /root/tp/parte1
bash /root/tp/parte2
chmod 700 /www_dir/lost+found/;bash /root/tp/parte3
reboot
